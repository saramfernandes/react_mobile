import HomeScreen from './src/screens/Home/HomeScreen';

export default function App() {
  return <HomeScreen/>
}

