export interface LetrasButtonProps {
	onConfirm: (letras: string) => void;
}
