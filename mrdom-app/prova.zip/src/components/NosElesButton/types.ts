export type NosElesButtonProps = {
  onPress: () => (option: string) => void;
};
